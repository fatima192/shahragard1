package com.example.asus.proto5phase3;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;



public class MakeTripFragment extends Fragment {

    public static MakeTripFragment newInstance() {
        MakeTripFragment fragment = new MakeTripFragment();
        return fragment;
    }
    MakeTripActivity trip;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        trip=new MakeTripActivity();
       //trip.creat();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_make_trip, container, false);
    }
}
